// Task Management System Lambda Handler
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, PutCommand, UpdateCommand, DeleteCommand, QueryCommand, TransactWriteCommand } = require('@aws-sdk/lib-dynamodb');
const { SNSClient, PublishCommand } = require('@aws-sdk/client-sns');
const { CognitoIdentityProviderClient, ListUsersCommand } = require('@aws-sdk/client-cognito-identity-provider');
const { v4: uuidv4 } = require('uuid');

const dynamoDbClient = new DynamoDBClient({
  region: process.env.AWS_REGION || 'eu-west-1'
});
const dynamodb = DynamoDBDocumentClient.from(dynamoDbClient);

const snsClient = new SNSClient({
  region: process.env.AWS_REGION || 'eu-west-1'
});

const cognitoClient = new CognitoIdentityProviderClient({
  region: process.env.AWS_REGION || 'eu-west-1'
});

const VALID_TASK_STATUSES = ['Not Started', 'In Progress', 'Completed'];
const VALID_PRIORITIES = ['Low', 'Medium', 'High'];
const VALID_ROLES = ['admin', 'member'];

class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ValidationError';
    this.errorType = 'ValidationError';
  }
}

class AuthorizationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'AuthorizationError';
    this.errorType = 'AuthorizationError';
  }
}

class NotFoundError extends Error {
  constructor(message) {
    super(message);
    this.name = 'NotFoundError';
    this.errorType = 'NotFoundError';
  }
}

function logError(operation, error, context = {}) {
  console.error(`[${operation}] Error:`, {
    message: error.message,
    errorType: error.errorType || error.name,
    stack: error.stack,
    context,
    timestamp: new Date().toISOString()
  });
}

function logSuccess(operation, result, context = {}) {
  console.log(`[${operation}] Success:`, {
    result: typeof result === 'object' ? JSON.stringify(result, null, 2) : result,
    context,
    timestamp: new Date().toISOString()
  });
}

function validateRequired(value, fieldName) {
  if (!value || (typeof value === 'string' && value.trim().length === 0)) {
    throw new ValidationError(`${fieldName} is required and cannot be empty`);
  }
}

function validateEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    throw new ValidationError('Invalid email format');
  }
}

function validateLength(value, fieldName, minLength, maxLength) {
  if (value && typeof value === 'string') {
    const trimmedValue = value.trim();
    if (trimmedValue.length < minLength || trimmedValue.length > maxLength) {
      throw new ValidationError(`${fieldName} must be between ${minLength} and ${maxLength} characters`);
    }
  }
}

function normalizeUserId(identity) {
  console.log('[NORMALIZE_USER_ID] Processing identity:', JSON.stringify(identity, null, 2));
  
  const possibleIds = [
    identity.sub,
    identity.username,
    identity['cognito:username'],
    identity.email,
    identity['custom:email']
  ];
  
  for (let i = 0; i < possibleIds.length; i++) {
    const id = possibleIds[i];
    if (id && typeof id === 'string' && id.trim()) {
      const normalizedId = id.trim();
      console.log(`[NORMALIZE_USER_ID] Selected ID from position ${i}: ${normalizedId}`);
      return normalizedId;
    }
  }
  
  console.error('[NORMALIZE_USER_ID] No valid user ID found in identity:', identity);
  throw new AuthorizationError('Unable to determine user identity');
}

// FIXED: Enhanced team membership validation function
async function validateTeamMembership(teamId, userId, requiredRole = null) {
  console.log(`[VALIDATE_TEAM_MEMBERSHIP] Checking membership for user ${userId} in team ${teamId}, required role: ${requiredRole}`);
  
  try {
    // Check if team exists first
    const teamResult = await dynamodb.send(new GetCommand({
      TableName: process.env.DYNAMODB_TEAMS_TABLE,
      Key: { teamId }
    }));
    
    if (!teamResult.Item) {
      console.log(`[VALIDATE_TEAM_MEMBERSHIP] Team ${teamId} not found`);
      throw new NotFoundError('Team not found');
    }
    
    // Check user membership
    const membershipResult = await dynamodb.send(new GetCommand({
      TableName: process.env.DYNAMODB_MEMBERSHIPS_TABLE,
      Key: { teamId, userId }
    }));
    
    if (!membershipResult.Item) {
      console.log(`[VALIDATE_TEAM_MEMBERSHIP] User ${userId} is not a member of team ${teamId}`);
      throw new AuthorizationError('You are not a member of this team');
    }
    
    const membership = membershipResult.Item;
    console.log(`[VALIDATE_TEAM_MEMBERSHIP] User role: ${membership.role}`);
    
    // Check role requirement if specified
    if (requiredRole && membership.role !== requiredRole) {
      console.log(`[VALIDATE_TEAM_MEMBERSHIP] User role ${membership.role} does not match required role ${requiredRole}`);
      throw new AuthorizationError(`This action requires ${requiredRole} role`);
    }
    
    return {
      team: teamResult.Item,
      membership: membership,
      isAdmin: membership.role === 'admin'
    };
    
  } catch (error) {
    if (error instanceof NotFoundError || error instanceof AuthorizationError) {
      throw error;
    }
    console.error(`[VALIDATE_TEAM_MEMBERSHIP] Unexpected error:`, error);
    throw new Error(`Failed to validate team membership: ${error.message}`);
  }
}

async function sendNotification(subject, message, recipientId, metadata = {}) {
  try {
    const params = {
      TopicArn: process.env.SNS_TOPIC_ARN,
      Subject: subject,
      Message: JSON.stringify({
        recipientId: recipientId,
        message: message,
        metadata: metadata,
        timestamp: new Date().toISOString()
      })
    };
    
    await snsClient.send(new PublishCommand(params));
    logSuccess('SEND_NOTIFICATION', 'Notification sent successfully', { subject, recipientId });
  } catch (error) {
    logError('SEND_NOTIFICATION', error, { subject, recipientId });
    console.warn('Failed to send notification, continuing execution');
  }
}

exports.handler = async (event) => {
  console.log('Lambda invocation started:', {
    timestamp: new Date().toISOString(),
    event: JSON.stringify(event, null, 2)
  });
  
  try {
    let fieldName, args, identity;
    
    if (event.info && event.info.fieldName) {
      fieldName = event.info.fieldName;
      args = event.arguments || {};
      identity = event.identity;
    } else if (event.fieldName) {
      fieldName = event.fieldName;
      args = event.arguments || {};
      identity = event.identity;
    } else if (event.payload) {
      fieldName = event.payload.fieldName;
      args = event.payload.arguments ? JSON.parse(event.payload.arguments) : {};
      identity = event.payload.identity ? JSON.parse(event.payload.identity) : null;
    } else {
      fieldName = event.operation || event.field;
      args = event.variables || event.arguments || {};
      identity = event.requestContext?.identity || event.identity;
    }
    
    console.log('Extracted event data:', {
      fieldName,
      args,
      identity: identity ? 'present' : 'missing',
      identityKeys: identity ? Object.keys(identity) : []
    });
    
    if (!fieldName) {
      throw new ValidationError('Missing fieldName in event - unable to determine operation');
    }
    
    if (!identity) {
      throw new AuthorizationError('Authentication required - missing user identity');
    }
    
    let userId;
    try {
      userId = normalizeUserId(identity);
      console.log(`[HANDLER] Normalized user ID: ${userId}`);
    } catch (error) {
      logError('USER_ID_NORMALIZATION', error, { identity });
      throw error;
    }
    
    const userGroups = identity['cognito:groups'] || [];
    
    console.log('Processing request:', {
      fieldName,
      userId,
      userGroups,
      argsCount: args ? Object.keys(args).length : 0
    });

    let result;
    
    switch (fieldName) {
      case 'createTeam':
        result = await createTeam(args, userId, userGroups);
        break;
      case 'addMember':
        result = await addMember(args, userId, userGroups);
        break;
      case 'createTask':
        result = await createTask(args, userId, userGroups);
        break;
      case 'updateTask':
        result = await updateTask(args, userId, userGroups);
        break;
      case 'updateTaskDetails':
        result = await updateTaskDetails(args, userId, userGroups);
        break;
      case 'deleteTask':
        result = await deleteTask(args, userId, userGroups);
        break;
      case 'listTeams':
        result = await listTeams(userId);
        break;
      case 'listTasks':
        result = await listTasks(args, userId, userGroups);
        break;
      case 'searchTasks':
        result = await searchTasks(args, userId, userGroups);
        break;
      case 'listMembers':
        result = await listMembers(args, userId, userGroups);
        break;
      case 'getUser':
        result = await getUser(args, userId);
        break;
      // FIXED: Add new operations for team validation
      case 'getTeam':
        result = await getTeam(args, userId, userGroups);
        break;
      case 'getUserTeams':
        result = await getUserTeams(userId);
        break;
      default:
        throw new ValidationError(`Unknown GraphQL field: ${fieldName}`);
    }
    
    logSuccess('HANDLER', `${fieldName} completed`, { 
      userId, 
      resultType: typeof result,
      resultCount: Array.isArray(result) ? result.length : 'N/A'
    });
    
    return result;
    
  } catch (err) {
    logError('HANDLER', err, { 
      fieldName: fieldName || 'unknown', 
      userId: userId || 'unknown',
      eventStructure: Object.keys(event || {})
    });
    
    if (err instanceof ValidationError || err instanceof AuthorizationError || err instanceof NotFoundError) {
      throw err;
    }
    
    const error = new Error(`Operation failed: ${err.message}`);
    error.errorType = 'InternalError';
    throw error;
  }
};

async function createTeam(args, userId, userGroups) {
  console.log('[CREATE_TEAM] Starting team creation:', { args, userId });
  
  validateRequired(args?.name, 'Team name');
  validateLength(args.name, 'Team name', 1, 100);
  
  const teamId = uuidv4();
  const timestamp = new Date().toISOString();
  
  const team = {
    teamId,
    name: args.name.trim(),
    adminId: userId,
    createdAt: timestamp
  };
  
  const membership = {
    teamId,
    userId,
    role: 'admin',
    joinedAt: timestamp
  };
  
  console.log('[CREATE_TEAM] Creating team and membership:', {
    team,
    membership
  });
  
  try {
    const transactParams = {
      TransactItems: [
        {
          Put: {
            TableName: process.env.DYNAMODB_TEAMS_TABLE,
            Item: team,
            ConditionExpression: 'attribute_not_exists(teamId)'
          }
        },
        {
          Put: {
            TableName: process.env.DYNAMODB_MEMBERSHIPS_TABLE,
            Item: membership,
            ConditionExpression: 'attribute_not_exists(teamId) AND attribute_not_exists(userId)'
          }
        }
      ]
    };
    
    await dynamodb.send(new TransactWriteCommand(transactParams));
    
    await sendNotification(
      'Team Created Successfully',
      `Your team "${team.name}" has been created successfully. You can now add members and create tasks.`,
      userId,
      {
        teamId,
        teamName: team.name,
        action: 'team_created'
      }
    );
    
    logSuccess('CREATE_TEAM', 'Team created successfully', { teamId, teamName: team.name, userId });
    
    return {
      teamId: team.teamId,
      name: team.name,
      adminId: team.adminId,
      createdAt: team.createdAt,
      userRole: 'admin'
    };
    
  } catch (error) {
    if (error.name === 'ConditionalCheckFailedException') {
      throw new ValidationError('Team creation failed - duplicate data detected');
    }
    logError('CREATE_TEAM', error, { teamId, userId });
    throw new Error(`Failed to create team: ${error.message}`);
  }
}

async function addMember(args, userId, userGroups) {
  console.log('[ADD_MEMBER] Starting member addition:', { args, userId });
  
  validateRequired(args?.teamId, 'Team ID');
  validateRequired(args?.email, 'Email');
  validateEmail(args.email);
  
  try {
    // FIXED: Use the enhanced validation function
    const { team } = await validateTeamMembership(args.teamId, userId, 'admin');
    
    let memberUserId;
    try {
      const listUsersParams = {
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        Filter: `email = "${args.email}"`,
        Limit: 1
      };
      
      const listUsersCommand = new ListUsersCommand(listUsersParams);
      const listUsersResponse = await cognitoClient.send(listUsersCommand);
      
      if (listUsersResponse.Users && listUsersResponse.Users.length > 0) {
        const userAttributes = listUsersResponse.Users[0].Attributes;
        const subAttr = userAttributes.find(attr => attr.Name === 'sub');
        if (subAttr && subAttr.Value) {
          memberUserId = subAttr.Value;
        } else {
          throw new ValidationError('User sub not found');
        }
      } else {
        throw new ValidationError('User with this email does not exist');
      }
    } catch (cognitoError) {
      logError('ADD_MEMBER_COGNITO', cognitoError, { email: args.email });
      if (cognitoError instanceof ValidationError) {
        throw cognitoError;
      }
      throw new Error('Failed to verify user email');
    }
    
    const existingMember = await dynamodb.send(new GetCommand({
      TableName: process.env.DYNAMODB_MEMBERSHIPS_TABLE,
      Key: { teamId: args.teamId, userId: memberUserId }
    }));
    
    if (existingMember.Item) {
      throw new ValidationError('User is already a member of this team');
    }
    
    const membership = {
      teamId: args.teamId,
      userId: memberUserId,
      role: 'member',
      joinedAt: new Date().toISOString(),
      addedBy: userId
    };
    
    await dynamodb.send(new PutCommand({
      TableName: process.env.DYNAMODB_MEMBERSHIPS_TABLE,
      Item: membership
    }));
    
    await sendNotification(
      'Team Invitation',
      `You have been added to the team "${team.name}". Start collaborating on tasks now!`,
      memberUserId,
      {
        teamId: args.teamId,
        teamName: team.name,
        invitedBy: userId,
        action: 'team_invitation'
      }
    );
    
    logSuccess('ADD_MEMBER', 'Member added successfully', { 
      teamId: args.teamId, 
      newMember: memberUserId,
      teamName: team.name
    });
    
    return membership;
    
  } catch (error) {
    if (error instanceof ValidationError || error instanceof AuthorizationError || error instanceof NotFoundError) {
      throw error;
    }
    logError('ADD_MEMBER', error, { teamId: args.teamId, email: args.email });
    throw new Error(`Failed to add member: ${error.message}`);
  }
}

async function createTask(args, userId, userGroups) {
  console.log('[CREATE_TASK] Starting task creation:', { args, userId });
  
  validateRequired(args?.teamId, 'Team ID');
  validateRequired(args?.title, 'Task title');
  validateRequired(args?.description, 'Task description');
  validateLength(args.title, 'Task title', 1, 200);
  validateLength(args.description, 'Task description', 1, 1000);
  
  if (args.priority && !VALID_PRIORITIES.includes(args.priority)) {
    throw new ValidationError(`Invalid priority. Must be one of: ${VALID_PRIORITIES.join(', ')}`);
  }
  
  if (args.deadline) {
    const deadlineDate = new Date(args.deadline);
    if (isNaN(deadlineDate.getTime())) {
      throw new ValidationError('Invalid deadline format. Use ISO date format (YYYY-MM-DD)');
    }
    if (deadlineDate < new Date()) {
      throw new ValidationError('Deadline cannot be in the past');
    }
  }
  
  try {
    // FIXED: Use the enhanced validation function
    const { team } = await validateTeamMembership(args.teamId, userId, 'admin');
    
    if (args.assignedTo) {
      const assigneeCheck = await dynamodb.send(new GetCommand({
        TableName: process.env.DYNAMODB_MEMBERSHIPS_TABLE,
        Key: { teamId: args.teamId, userId: args.assignedTo }
      }));
      
      if (!assigneeCheck.Item) {
        throw new ValidationError('Cannot assign task to user who is not a team member');
      }
    }
    
    const taskId = uuidv4();
    const timestamp = new Date().toISOString();
    
    const task = {
      teamId: args.teamId,
      taskId,
      title: args.title.trim(),
      description: args.description.trim(),
      assignedTo: args.assignedTo || null,
      status: 'Not Started',
      priority: args.priority || 'Medium',
      deadline: args.deadline || null,
      createdBy: userId,
      createdAt: timestamp,
      updatedAt: timestamp,
      updatedBy: userId
    };
    
    await dynamodb.send(new PutCommand({
      TableName: process.env.DYNAMODB_TASKS_TABLE,
      Item: task
    }));
    
    if (args.assignedTo) {
      await sendNotification(
        'New Task Assignment',
        `You have been assigned a new task: "${args.title}" in team "${team.name}". Priority: ${task.priority}`,
        args.assignedTo,
        {
          taskId,
          taskTitle: args.title,
          teamId: args.teamId,
          teamName: team.name,
          priority: task.priority,
          deadline: task.deadline,
          action: 'task_assigned'
        }
      );
    }
    
    logSuccess('CREATE_TASK', 'Task created successfully', { 
      taskId, 
      title: task.title,
      assignedTo: task.assignedTo,
      priority: task.priority
    });
    
    return task;
    
  } catch (error) {
    if (error instanceof ValidationError || error instanceof AuthorizationError || error instanceof NotFoundError) {
      throw error;
    }
    logError('CREATE_TASK', error, { teamId: args.teamId, title: args.title });
    throw new Error(`Failed to create task: ${error.message}`);
  }
}

async function updateTask(args, userId, userGroups) {
  console.log('[UPDATE_TASK] Starting task update:', { args, userId });
  
  validateRequired(args?.teamId, 'Team ID');
  validateRequired(args?.taskId, 'Task ID');
  validateRequired(args?.status, 'Task status');
  
  if (!VALID_TASK_STATUSES.includes(args.status)) {
    throw new ValidationError(`Invalid status. Must be one of: ${VALID_TASK_STATUSES.join(', ')}`);
  }
  
  try {
    // FIXED: Use the enhanced validation function
    const { team, membership } = await validateTeamMembership(args.teamId, userId);
    
    const taskResult = await dynamodb.send(new GetCommand({
      TableName: process.env.DYNAMODB_TASKS_TABLE,
      Key: { teamId: args.teamId, taskId: args.taskId }
    }));
    
    if (!taskResult.Item) {
      throw new NotFoundError('Task not found');
    }
    
    const task = taskResult.Item;
    const oldStatus = task.status;
    
    const canUpdate = task.assignedTo === userId || membership.role === 'admin';
    
    if (!canUpdate) {
      throw new AuthorizationError('You can only update tasks assigned to you or if you are a team admin');
    }
    
    const timestamp = new Date().toISOString();
    
    const updateParams = {
      TableName: process.env.DYNAMODB_TASKS_TABLE,
      Key: { teamId: args.teamId, taskId: args.taskId },
      UpdateExpression: 'SET #status = :status, updatedAt = :updatedAt, updatedBy = :updatedBy',
      ExpressionAttributeNames: {
        '#status': 'status'
      },
      ExpressionAttributeValues: {
        ':status': args.status,
        ':updatedAt': timestamp,
        ':updatedBy': userId
      },
      ReturnValues: 'ALL_NEW'
    };
    
    const result = await dynamodb.send(new UpdateCommand(updateParams));
    
    if (task.assignedTo && oldStatus !== args.status) {
      await sendNotification(
        'Task Status Updated',
        `The task "${task.title}" in team "${team.name}" has been updated to "${args.status}" by ${userId}.`,
        task.assignedTo,
        {
          taskId: args.taskId,
          taskTitle: task.title,
          teamId: args.teamId,
          teamName: team.name,
          oldStatus,
          newStatus: args.status,
          action: 'task_status_updated'
        }
      );
    }
    
    logSuccess('UPDATE_TASK', 'Task status updated successfully', { 
      taskId: args.taskId, 
      status: args.status 
    });
    
    return result.Attributes;
    
  } catch (error) {
    if (error instanceof ValidationError || error instanceof AuthorizationError || error instanceof NotFoundError) {
      throw error;
    }
    logError('UPDATE_TASK', error, { teamId: args.teamId, taskId: args.taskId });
    throw new Error(`Failed to update task: ${error.message}`);
  }
}

async function updateTaskDetails(args, userId, userGroups) {
  console.log('[UPDATE_TASK_DETAILS] Starting task details update:', { args, userId });
  
  validateRequired(args?.teamId, 'Team ID');
  validateRequired(args?.taskId, 'Task ID');
  
  if (args.title) validateLength(args.title, 'Task title', 1, 200);
  if (args.description) validateLength(args.description, 'Task description', 1, 1000);
  if (args.priority && !VALID_PRIORITIES.includes(args.priority)) {
    throw new ValidationError(`Invalid priority. Must be one of: ${VALID_PRIORITIES.join(', ')}`);
  }
  if (args.deadline) {
    const deadlineDate = new Date(args.deadline);
    if (isNaN(deadlineDate.getTime())) {
      throw new ValidationError('Invalid deadline format. Use ISO date format (YYYY-MM-DD)');
    }
    if (deadlineDate < new Date()) {
      throw new ValidationError('Deadline cannot be in the past');
    }
  }
  
  try {
    // FIXED: Use the enhanced validation function
    const { team } = await validateTeamMembership(args.teamId, userId, 'admin');
    
    const taskResult = await dynamodb.send(new GetCommand({
      TableName: process.env.DYNAMODB_TASKS_TABLE,
      Key: { teamId: args.teamId, taskId: args.taskId }
    }));
    
    if (!taskResult.Item) {
      throw new NotFoundError('Task not found');
    }
    
    const task = taskResult.Item;
    
    if (args.assignedTo) {
      const assigneeCheck = await dynamodb.send(new GetCommand({
        TableName: process.env.DYNAMODB_MEMBERSHIPS_TABLE,
        Key: { teamId: args.teamId, userId: args.assignedTo }
      }));
      
      if (!assigneeCheck.Item && args.assignedTo !== null) {
        throw new ValidationError('Cannot assign task to user who is not a team member');
      }
    }
    
    const timestamp = new Date().toISOString();
    let updateExpression = 'SET updatedAt = :updatedAt, updatedBy = :updatedBy';
    const expressionAttributeNames = {};
    const expressionAttributeValues = {
      ':updatedAt': timestamp,
      ':updatedBy': userId
    };
    
    if (args.title) {
      updateExpression += ', title = :title';
      expressionAttributeValues[':title'] = args.title.trim();
    }
    if (args.description) {
      updateExpression += ', description = :description';
      expressionAttributeValues[':description'] = args.description.trim();
    }
    if (args.priority) {
      updateExpression += ', priority = :priority';
      expressionAttributeValues[':priority'] = args.priority;
    }
    if (args.deadline !== undefined) {
      updateExpression += ', deadline = :deadline';
      expressionAttributeValues[':deadline'] = args.deadline || null;
    }
    if (args.assignedTo !== undefined) {
      updateExpression += ', assignedTo = :assignedTo';
      expressionAttributeValues[':assignedTo'] = args.assignedTo || null;
    }
    
    const updateParams = {
      TableName: process.env.DYNAMODB_TASKS_TABLE,
      Key: { teamId: args.teamId, taskId: args.taskId },
      UpdateExpression: updateExpression,
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
      ReturnValues: 'ALL_NEW'
    };
    
    const result = await dynamodb.send(new UpdateCommand(updateParams));
    
    if (args.assignedTo && args.assignedTo !== task.assignedTo) {
      await sendNotification(
        'Task Reassigned',
        `The task "${task.title}" in team "${team.name}" has been reassigned to you.`,
        args.assignedTo,
        {
          taskId: args.taskId,
          taskTitle: task.title,
          teamId: args.teamId,
          teamName: team.name,
          action: 'task_reassigned'
        }
      );
    }
    
    logSuccess('UPDATE_TASK_DETAILS', 'Task details updated successfully', { 
      taskId: args.taskId 
    });
    
    return result.Attributes;
    
  } catch (error) {
    if (error instanceof ValidationError || error instanceof AuthorizationError || error instanceof NotFoundError) {
      throw error;
    }
    logError('UPDATE_TASK_DETAILS', error, { teamId: args.teamId, taskId: args.taskId });
    throw new Error(`Failed to update task details: ${error.message}`);
  }
}

async function deleteTask(args, userId, userGroups) {
  console.log('[DELETE_TASK] Starting task deletion:', { args, userId });
  
  validateRequired(args?.teamId, 'Team ID');
  validateRequired(args?.taskId, 'Task ID');
  
  try {
    // FIXED: Use the enhanced validation function
    const { team } = await validateTeamMembership(args.teamId, userId, 'admin');
    
    const taskResult = await dynamodb.send(new GetCommand({
      TableName: process.env.DYNAMODB_TASKS_TABLE,
      Key: { teamId: args.teamId, taskId: args.taskId }
    }));
    
    if (!taskResult.Item) {
      throw new NotFoundError('Task not found');
    }
    
    const task = taskResult.Item;
    
    await dynamodb.send(new DeleteCommand({
      TableName: process.env.DYNAMODB_TASKS_TABLE,
      Key: { teamId: args.teamId, taskId: args.taskId }
    }));
    
    if (task.assignedTo) {
      await sendNotification(
        'Task Deleted',
        `The task "${task.title}" in team "${team.name}" has been deleted.`,
        task.assignedTo,
        {
          taskId: args.taskId,
          taskTitle: task.title,
          teamId: args.teamId,
          teamName: team.name,
          action: 'task_deleted'
        }
      );
    }
    
    logSuccess('DELETE_TASK', 'Task deleted successfully', { 
      taskId: args.taskId 
    });
    
    return { success: true };
    
  } catch (error) {
    if (error instanceof ValidationError || error instanceof AuthorizationError || error instanceof NotFoundError) {
      throw error;
    }
    logError('DELETE_TASK', error, { teamId: args.teamId, taskId: args.taskId });
    throw new Error(`Failed to delete task: ${error.message}`);
  }
}

async function listTeams(userId) {
  console.log('[LIST_TEAMS] Starting team list for user:', userId);
  
  try {
    const memberships = await dynamodb.send(new QueryCommand({
      TableName: process.env.DYNAMODB_MEMBERSHIPS_TABLE,
      IndexName: 'userId-index',
      KeyConditionExpression: 'userId = :userId',
      ExpressionAttributeValues: {
        ':userId': userId
      }
    }));
    
    console.log('[LIST_TEAMS] Found memberships:', memberships.Items?.length || 0);
    
    if (!memberships.Items || memberships.Items.length === 0) {
      console.log('[LIST_TEAMS] No team memberships found for user:', userId);
      return [];
    }
    
    const teamIds = memberships.Items.map(item => item.teamId);
    console.log('[LIST_TEAMS] Team IDs to fetch:', teamIds);
    
    const teams = [];
    for (const teamId of teamIds) {
      const teamResult = await dynamodb.send(new GetCommand({
        TableName: process.env.DYNAMODB_TEAMS_TABLE,
        Key: { teamId }
      }));
      
      if (teamResult.Item) {
        const membership = memberships.Items.find(m => m.teamId === teamId);
        teams.push({
          ...teamResult.Item,
          userRole: membership.role
        });
      }
    }
    
    logSuccess('LIST_TEAMS', 'Teams retrieved successfully', { 
      teamCount: teams.length,
      userId
    });
    
    return teams;
    
  } catch (error) {
    logError('LIST_TEAMS', error, { userId });
    throw new Error(`Failed to list teams: ${error.message}`);
  }
}

async function listTasks(args, userId, userGroups) {
  console.log('[LIST_TASKS] Starting task list:', { args, userId });
  
  validateRequired(args?.teamId, 'Team ID');
  
  try {
    // FIXED: Use the enhanced validation function
    await validateTeamMembership(args.teamId, userId);
    
    const tasks = await dynamodb.send(new QueryCommand({
      TableName: process.env.DYNAMODB_TASKS_TABLE,
      KeyConditionExpression: 'teamId = :teamId',
      ExpressionAttributeValues: {
        ':teamId': args.teamId
      }
    }));
    
    logSuccess('LIST_TASKS', 'Tasks retrieved successfully', { 
      teamId: args.teamId, 
      taskCount: tasks.Items?.length || 0 
    });
    
    return tasks.Items || [];
    
  } catch (error) {
    if (error instanceof ValidationError || error instanceof AuthorizationError || error instanceof NotFoundError) {
      throw error;
    }
    logError('LIST_TASKS', error, { teamId: args.teamId });
    throw new Error(`Failed to list tasks: ${error.message}`);
  }
}

async function searchTasks(args, userId, userGroups) {
  console.log('[SEARCH_TASKS] Starting task search:', { args, userId });
  
  validateRequired(args?.teamId, 'Team ID');
  validateRequired(args?.query, 'Search query');
  validateLength(args.query, 'Search query', 1, 200);
  
  try {
    // FIXED: Use the enhanced validation function
    await validateTeamMembership(args.teamId, userId);
    
    const tasks = await dynamodb.send(new QueryCommand({
      TableName: process.env.DYNAMODB_TASKS_TABLE,
      KeyConditionExpression: 'teamId = :teamId',
      ExpressionAttributeValues: {
        ':teamId': args.teamId
      }
    }));
    
    const queryLower = args.query.toLowerCase();
    const filteredTasks = (tasks.Items || []).filter(task => 
      task.title.toLowerCase().includes(queryLower) || 
      task.description.toLowerCase().includes(queryLower)
    );
    
    logSuccess('SEARCH_TASKS', 'Tasks searched successfully', { 
      teamId: args.teamId, 
      query: args.query, 
      taskCount: filteredTasks.length 
    });
    
    return filteredTasks;
    
  } catch (error) {
    if (error instanceof ValidationError || error instanceof AuthorizationError || error instanceof NotFoundError) {
      throw error;
    }
    logError('SEARCH_TASKS', error, { teamId: args.teamId, query: args.query });
    throw new Error(`Failed to search tasks: ${error.message}`);
  }
}

async function listMembers(args, userId, userGroups) {
  console.log('[LIST_MEMBERS] Starting member list:', { args, userId });
  
  validateRequired(args?.teamId, 'Team ID');
  
  try {
    // FIXED: Use the enhanced validation function
    await validateTeamMembership(args.teamId, userId);
    
    const members = await dynamodb.send(new QueryCommand({
      TableName: process.env.DYNAMODB_MEMBERSHIPS_TABLE,
      KeyConditionExpression: 'teamId = :teamId',
      ExpressionAttributeValues: {
        ':teamId': args.teamId
      }
    }));
    
    console.log('[LIST_MEMBERS] Found members:', members.Items?.length || 0);
    
    logSuccess('LIST_MEMBERS', 'Members retrieved successfully', { 
      teamId: args.teamId, 
      memberCount: members.Items?.length || 0 
    });
    
    return members.Items || [];
    
  } catch (error) {
    if (error instanceof ValidationError || error instanceof AuthorizationError || error instanceof NotFoundError) {
      throw error;
    }
    logError('LIST_MEMBERS', error, { teamId: args.teamId });
    throw new Error(`Failed to list members: ${error.message}`);
  }
}

async function getUser(args, userId) {
  console.log('[GET_USER] Starting user retrieval:', { args, userId });
  
  const targetUserId = args?.userId || userId;
  
  try {
    const userResult = await dynamodb.send(new GetCommand({
      TableName: process.env.DYNAMODB_USERS_TABLE,
      Key: { userId: targetUserId }
    }));
    
    if (!userResult.Item) {
      throw new NotFoundError('User not found');
    }
    
    logSuccess('GET_USER', 'User retrieved successfully', { 
      targetUserId 
    });
    
    return userResult.Item;
    
  } catch (error) {
    if (error instanceof NotFoundError) {
      throw error;
    }
    logError('GET_USER', error, { targetUserId });
    throw new Error(`Failed to get user: ${error.message}`);
  }
}

// FIXED: Add new functions for enhanced team validation
async function getTeam(args, userId, userGroups) {
  console.log('[GET_TEAM] Starting team retrieval:', { args, userId });
  
  validateRequired(args?.teamId, 'Team ID');
  
  try {
    const { team, membership } = await validateTeamMembership(args.teamId, userId);
    
    const result = {
      ...team,
      userRole: membership.role,
      isAdmin: membership.role === 'admin'
    };
    
    logSuccess('GET_TEAM', 'Team retrieved successfully', { 
      teamId: args.teamId,
      userRole: membership.role
    });
    
    return result;
    
  } catch (error) {
    if (error instanceof ValidationError || error instanceof AuthorizationError || error instanceof NotFoundError) {
      throw error;
    }
    logError('GET_TEAM', error, { teamId: args.teamId });
    throw new Error(`Failed to get team: ${error.message}`);
  }
}

async function getUserTeams(userId) {
  console.log('[GET_USER_TEAMS] Starting user teams retrieval:', { userId });
  
  try {
    // This is essentially the same as listTeams but with a different name for clarity
    return await listTeams(userId);
    
  } catch (error) {
    logError('GET_USER_TEAMS', error, { userId });
    throw new Error(`Failed to get user teams: ${error.message}`);
  }
}